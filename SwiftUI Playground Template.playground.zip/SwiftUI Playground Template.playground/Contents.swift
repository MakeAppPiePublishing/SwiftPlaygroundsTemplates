/// Basic Template for Swift Playgrounds
/// Save to your playgrounds folder and duplicate it.

import SwiftUI

struct ContentView:View{
    var body: some View{
        Text("Hello, Swift Playgrounds!")
    }
}

import PlaygroundSupport
PlaygroundPage.current.setLiveView(ContentView())
