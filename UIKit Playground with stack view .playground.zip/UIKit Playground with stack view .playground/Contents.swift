/// A simple template for getting started with UIKit in Playgrounds. see the notes in loadview for setting the frame. Save and duplcate this for  ew projects.
/// Steve Lipton https://makeapppie.com

import UIKit


class ViewController:UIViewController{
    override func viewDidLoad() {
        super.viewDidLoad() //Superflous, but I do it anyway. 
        let label = UILabel()
            //I create a quick and dirty vStack to get coding quickly. change this to your favorite way of programmatically handling UIKit. 
        label.text = "Hello Swift Playgrounds"
        label.textAlignment = .center
        let vStack = UIStackView(frame: view.frame)
        vStack.axis = .vertical
        vStack.alignment = .fill
        vStack.distribution = .fill
        view.addSubview(vStack)
        vStack.addArrangedSubview(label)
        
    }
    /// One of the radars I filed. I was just using `viewDidLoad`, and for some reason my playgrounds started crashing suddenly. Apple changed the playgrounds so it requires `loadView` to load the initial view I usually put this boilerplate code in  and go do the rest in `viewDidLoad`. The actual size of the presented view's frame is a little strange. See my course for playgrounds on LinkedIn Learning for the full story.
    
    override func loadView() {
        //let view = UIView(frame: UIScreen.main.bounds)
            //  On an iPad , the following works well. uncomment it and delete the above. 
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 375, height: 667))
        view.backgroundColor = .systemBackground
        self.view = view
    }
}

import PlaygroundSupport
let vc = ViewController()
PlaygroundPage.current.setLiveView(vc)
